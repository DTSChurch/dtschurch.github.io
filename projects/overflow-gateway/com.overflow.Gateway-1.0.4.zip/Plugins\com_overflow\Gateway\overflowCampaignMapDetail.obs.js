System.register(['vue', '@Obsidian/Controls/notificationBox.obs', '@Obsidian/Templates/detailBlock', '@Obsidian/Enums/Controls/detailPanelMode', '@Obsidian/Controls/attributeValuesContainer.obs', '@Obsidian/Controls/checkBox.obs', '@Obsidian/Utility/block', '@Obsidian/Utility/component', '@Obsidian/Controls/accountPicker.obs', '@Obsidian/Controls/dropDownList.obs', '@Obsidian/Controls/valueDetailList.obs', '@Obsidian/Core/Controls/valueDetailListItemBuilder'], (function (exports) {
  'use strict';
  var defineComponent, ref, computed, watch, openBlock, createElementBlock, createElementVNode, createVNode, unref, isRef, Fragment, createBlock, createCommentVNode, withCtx, NotificationBox, DetailBlock, DetailPanelMode, AttributeValuesContainer, CheckBox, setPropertiesBoxValue, watchPropertyChanges, useConfigurationValues, useInvokeBlockAction, onConfigurationValuesChanged, useReloadBlock, useEntityDetailBlock, propertyRef, updateRefValue, AccountPicker, DropDownList, ValueDetailList, ValueDetailListItemBuilder;
  return {
    setters: [function (module) {
      defineComponent = module.defineComponent;
      ref = module.ref;
      computed = module.computed;
      watch = module.watch;
      openBlock = module.openBlock;
      createElementBlock = module.createElementBlock;
      createElementVNode = module.createElementVNode;
      createVNode = module.createVNode;
      unref = module.unref;
      isRef = module.isRef;
      Fragment = module.Fragment;
      createBlock = module.createBlock;
      createCommentVNode = module.createCommentVNode;
      withCtx = module.withCtx;
    }, function (module) {
      NotificationBox = module["default"];
    }, function (module) {
      DetailBlock = module["default"];
    }, function (module) {
      DetailPanelMode = module.DetailPanelMode;
    }, function (module) {
      AttributeValuesContainer = module["default"];
    }, function (module) {
      CheckBox = module["default"];
    }, function (module) {
      setPropertiesBoxValue = module.setPropertiesBoxValue;
      watchPropertyChanges = module.watchPropertyChanges;
      useConfigurationValues = module.useConfigurationValues;
      useInvokeBlockAction = module.useInvokeBlockAction;
      onConfigurationValuesChanged = module.onConfigurationValuesChanged;
      useReloadBlock = module.useReloadBlock;
      useEntityDetailBlock = module.useEntityDetailBlock;
    }, function (module) {
      propertyRef = module.propertyRef;
      updateRefValue = module.updateRefValue;
    }, function (module) {
      AccountPicker = module["default"];
    }, function (module) {
      DropDownList = module["default"];
    }, function (module) {
      ValueDetailList = module["default"];
    }, function (module) {
      ValueDetailListItemBuilder = module.ValueDetailListItemBuilder;
    }],
    execute: (function () {

      function asyncGeneratorStep(n, t, e, r, o, a, c) {
        try {
          var i = n[a](c),
            u = i.value;
        } catch (n) {
          return void e(n);
        }
        i.done ? t(u) : Promise.resolve(u).then(r, o);
      }
      function _asyncToGenerator(n) {
        return function () {
          var t = this,
            e = arguments;
          return new Promise(function (r, o) {
            var a = n.apply(t, e);
            function _next(n) {
              asyncGeneratorStep(a, r, o, _next, _throw, "next", n);
            }
            function _throw(n) {
              asyncGeneratorStep(a, r, o, _next, _throw, "throw", n);
            }
            _next(void 0);
          });
        };
      }
      function _defineProperty(e, r, t) {
        return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
          value: t,
          enumerable: !0,
          configurable: !0,
          writable: !0
        }) : e[r] = t, e;
      }
      function ownKeys(e, r) {
        var t = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var o = Object.getOwnPropertySymbols(e);
          r && (o = o.filter(function (r) {
            return Object.getOwnPropertyDescriptor(e, r).enumerable;
          })), t.push.apply(t, o);
        }
        return t;
      }
      function _objectSpread2(e) {
        for (var r = 1; r < arguments.length; r++) {
          var t = null != arguments[r] ? arguments[r] : {};
          r % 2 ? ownKeys(Object(t), !0).forEach(function (r) {
            _defineProperty(e, r, t[r]);
          }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) {
            Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
          });
        }
        return e;
      }
      function _toPrimitive(t, r) {
        if ("object" != typeof t || !t) return t;
        var e = t[Symbol.toPrimitive];
        if (void 0 !== e) {
          var i = e.call(t, r || "default");
          if ("object" != typeof i) return i;
          throw new TypeError("@@toPrimitive must return a primitive value.");
        }
        return ("string" === r ? String : Number)(t);
      }
      function _toPropertyKey(t) {
        var i = _toPrimitive(t, "string");
        return "symbol" == typeof i ? i : i + "";
      }

      var _hoisted_1$1 = {
        class: "row"
      };
      var _hoisted_2$1 = {
        class: "col-md-6"
      };
      var _hoisted_3$1 = {
        class: "col-md-6"
      };
      var _hoisted_4 = {
        class: "row"
      };
      var _hoisted_5 = {
        class: "col-md-6"
      };
      var _hoisted_6 = {
        class: "col-md-6"
      };
      var script$2 = defineComponent({
        __name: 'editPanel.partial',
        props: {
          modelValue: {
            type: Object,
            required: true
          },
          options: {
            type: Object,
            required: true
          }
        },
        emits: ["update:modelValue", "propertyChanged"],
        setup(__props, _ref) {
          var _props$modelValue$bag, _props$modelValue$bag2, _props$modelValue$bag3, _props$modelValue$bag4, _props$modelValue$bag5, _props$modelValue$bag6, _props$modelValue$bag7, _props$modelValue$bag8, _props$modelValue$bag9, _props$modelValue$bag0, _props$modelValue$bag1, _props$modelValue$bag10;
          var __emit = _ref.emit;
          var props = __props;
          var emit = __emit;
          var attributes = ref((_props$modelValue$bag = (_props$modelValue$bag2 = props.modelValue.bag) === null || _props$modelValue$bag2 === void 0 ? void 0 : _props$modelValue$bag2.attributes) !== null && _props$modelValue$bag !== void 0 ? _props$modelValue$bag : {});
          var attributeValues = ref((_props$modelValue$bag3 = (_props$modelValue$bag4 = props.modelValue.bag) === null || _props$modelValue$bag4 === void 0 ? void 0 : _props$modelValue$bag4.attributeValues) !== null && _props$modelValue$bag3 !== void 0 ? _props$modelValue$bag3 : {});
          var isActive = propertyRef((_props$modelValue$bag5 = (_props$modelValue$bag6 = props.modelValue.bag) === null || _props$modelValue$bag6 === void 0 ? void 0 : _props$modelValue$bag6.isActive) !== null && _props$modelValue$bag5 !== void 0 ? _props$modelValue$bag5 : true, "IsActive");
          var financialAccount = propertyRef((_props$modelValue$bag7 = (_props$modelValue$bag8 = props.modelValue.bag) === null || _props$modelValue$bag8 === void 0 ? void 0 : _props$modelValue$bag8.financialAccount) !== null && _props$modelValue$bag7 !== void 0 ? _props$modelValue$bag7 : {}, "FinancialAccount");
          var campaignId = propertyRef((_props$modelValue$bag9 = (_props$modelValue$bag0 = props.modelValue.bag) === null || _props$modelValue$bag0 === void 0 ? void 0 : _props$modelValue$bag0.campaignId) !== null && _props$modelValue$bag9 !== void 0 ? _props$modelValue$bag9 : "", "CampaignId");
          var subcampaignId = propertyRef((_props$modelValue$bag1 = (_props$modelValue$bag10 = props.modelValue.bag) === null || _props$modelValue$bag10 === void 0 ? void 0 : _props$modelValue$bag10.subcampaignId) !== null && _props$modelValue$bag1 !== void 0 ? _props$modelValue$bag1 : "", "SubcampaignId");
          console.log("OverflowCampaignMapDetail.editPanel.partial.obs: modelValue", props.modelValue);
          console.log("OverflowCampaignMapDetail.editPanel.partial.obs: options", props.options);
          var propRefs = [isActive, financialAccount, campaignId, subcampaignId];
          var campaignItems = computed(() => (props.options.apiCampaigns || []).map(c => ({
            text: c.isArchived ? "".concat(c.name, " (Archived)") : c.name,
            value: c.id
          })));
          var subcampaignItems = computed(() => {
            if (!props.options.apiCampaigns || props.options.apiCampaigns.length === 0) {
              return [];
            }
            var selectedCampaign = props.options.apiCampaigns.find(c => c.id === campaignId.value);
            if (!selectedCampaign || !selectedCampaign.subcampaigns) {
              return [];
            }
            return selectedCampaign.subcampaigns.map(s => ({
              text: s.isArchived ? "".concat(s.name, " (Archived)") : s.name,
              value: s.id
            }));
          });
          watch(() => props.modelValue, () => {
            var _props$modelValue$bag11, _props$modelValue$bag12, _props$modelValue$bag13, _props$modelValue$bag14, _props$modelValue$bag15, _props$modelValue$bag16, _props$modelValue$bag17, _props$modelValue$bag18, _props$modelValue$bag19, _props$modelValue$bag20, _props$modelValue$bag21, _props$modelValue$bag22;
            updateRefValue(attributes, (_props$modelValue$bag11 = (_props$modelValue$bag12 = props.modelValue.bag) === null || _props$modelValue$bag12 === void 0 ? void 0 : _props$modelValue$bag12.attributes) !== null && _props$modelValue$bag11 !== void 0 ? _props$modelValue$bag11 : {});
            updateRefValue(attributeValues, (_props$modelValue$bag13 = (_props$modelValue$bag14 = props.modelValue.bag) === null || _props$modelValue$bag14 === void 0 ? void 0 : _props$modelValue$bag14.attributeValues) !== null && _props$modelValue$bag13 !== void 0 ? _props$modelValue$bag13 : {});
            updateRefValue(isActive, (_props$modelValue$bag15 = (_props$modelValue$bag16 = props.modelValue.bag) === null || _props$modelValue$bag16 === void 0 ? void 0 : _props$modelValue$bag16.isActive) !== null && _props$modelValue$bag15 !== void 0 ? _props$modelValue$bag15 : true);
            updateRefValue(financialAccount, (_props$modelValue$bag17 = (_props$modelValue$bag18 = props.modelValue.bag) === null || _props$modelValue$bag18 === void 0 ? void 0 : _props$modelValue$bag18.financialAccount) !== null && _props$modelValue$bag17 !== void 0 ? _props$modelValue$bag17 : {});
            updateRefValue(campaignId, (_props$modelValue$bag19 = (_props$modelValue$bag20 = props.modelValue.bag) === null || _props$modelValue$bag20 === void 0 ? void 0 : _props$modelValue$bag20.campaignId) !== null && _props$modelValue$bag19 !== void 0 ? _props$modelValue$bag19 : "");
            updateRefValue(subcampaignId, (_props$modelValue$bag21 = (_props$modelValue$bag22 = props.modelValue.bag) === null || _props$modelValue$bag22 === void 0 ? void 0 : _props$modelValue$bag22.subcampaignId) !== null && _props$modelValue$bag21 !== void 0 ? _props$modelValue$bag21 : "");
          });
          watch([attributeValues, ...propRefs], () => {
            var newValue = {
              bag: _objectSpread2({}, props.modelValue.bag)
            };
            setPropertiesBoxValue(newValue, "attributeValues", attributeValues.value);
            setPropertiesBoxValue(newValue, "isActive", isActive.value);
            setPropertiesBoxValue(newValue, "financialAccount", financialAccount.value);
            setPropertiesBoxValue(newValue, "campaignId", campaignId.value);
            setPropertiesBoxValue(newValue, "subcampaignId", subcampaignId.value);
            emit("update:modelValue", newValue);
          });
          watchPropertyChanges(propRefs, emit);
          return (_ctx, _cache) => {
            return openBlock(), createElementBlock("fieldset", null, [createElementVNode("div", _hoisted_1$1, [createElementVNode("div", _hoisted_2$1, [createVNode(unref(AccountPicker), {
              modelValue: unref(financialAccount),
              "onUpdate:modelValue": _cache[0] || (_cache[0] = $event => isRef(financialAccount) ? financialAccount.value = $event : null),
              label: "Financial Account",
              rules: "required"
            }, null, 8, ["modelValue"])]), createElementVNode("div", _hoisted_3$1, [createVNode(unref(CheckBox), {
              modelValue: unref(isActive),
              "onUpdate:modelValue": _cache[1] || (_cache[1] = $event => isRef(isActive) ? isActive.value = $event : null),
              label: "Active"
            }, null, 8, ["modelValue"])])]), createElementVNode("div", _hoisted_4, [createElementVNode("div", _hoisted_5, [createVNode(unref(DropDownList), {
              modelValue: unref(campaignId),
              "onUpdate:modelValue": _cache[2] || (_cache[2] = $event => isRef(campaignId) ? campaignId.value = $event : null),
              label: "Campaign",
              items: campaignItems.value,
              rules: "required"
            }, null, 8, ["modelValue", "items"])]), createElementVNode("div", _hoisted_6, [createVNode(unref(DropDownList), {
              modelValue: unref(subcampaignId),
              "onUpdate:modelValue": _cache[3] || (_cache[3] = $event => isRef(subcampaignId) ? subcampaignId.value = $event : null),
              label: "Subcampaign",
              items: subcampaignItems.value
            }, null, 8, ["modelValue", "items"])])]), createVNode(unref(AttributeValuesContainer), {
              modelValue: attributeValues.value,
              "onUpdate:modelValue": _cache[4] || (_cache[4] = $event => attributeValues.value = $event),
              attributes: attributes.value,
              isEditMode: "",
              numberOfColumns: 2
            }, null, 8, ["modelValue", "attributes"])]);
          };
        }
      });

      script$2.__file = "src/OverflowCampaignMapDetail/editPanel.partial.obs";

      var _hoisted_1 = {
        class: "row"
      };
      var _hoisted_2 = {
        class: "col-md-6"
      };
      var _hoisted_3 = {
        class: "col-md-6"
      };
      var script$1 = defineComponent({
        __name: 'viewPanel.partial',
        props: {
          modelValue: {
            type: Object,
            required: false
          },
          options: {
            type: Object,
            required: true
          }
        },
        setup(__props) {
          var _props$modelValue$att, _props$modelValue, _props$modelValue$att2, _props$modelValue2;
          var props = __props;
          var attributes = ref((_props$modelValue$att = (_props$modelValue = props.modelValue) === null || _props$modelValue === void 0 ? void 0 : _props$modelValue.attributes) !== null && _props$modelValue$att !== void 0 ? _props$modelValue$att : {});
          var attributeValues = ref((_props$modelValue$att2 = (_props$modelValue2 = props.modelValue) === null || _props$modelValue2 === void 0 ? void 0 : _props$modelValue2.attributeValues) !== null && _props$modelValue$att2 !== void 0 ? _props$modelValue$att2 : {});
          var topValues = computed(() => {
            var valueBuilder = new ValueDetailListItemBuilder();
            if (!props.modelValue) {
              return valueBuilder.build();
            }
            return valueBuilder.build();
          });
          var leftSideValues = computed(() => {
            var _props$modelValue$fin;
            var valueBuilder = new ValueDetailListItemBuilder();
            if (!props.modelValue) {
              return valueBuilder.build();
            }
            valueBuilder.addTextValue("Financial Account", ((_props$modelValue$fin = props.modelValue.financialAccount) === null || _props$modelValue$fin === void 0 ? void 0 : _props$modelValue$fin.text) || "Unknown Account");
            return valueBuilder.build();
          });
          var rightSideValues = computed(() => {
            var _props$options$apiCam, _props$modelValue4;
            var valueBuilder = new ValueDetailListItemBuilder();
            if (!props.modelValue) {
              return valueBuilder.build();
            }
            var campaign = (_props$options$apiCam = props.options.apiCampaigns) === null || _props$options$apiCam === void 0 ? void 0 : _props$options$apiCam.find(c => {
              var _props$modelValue3;
              return c.id === ((_props$modelValue3 = props.modelValue) === null || _props$modelValue3 === void 0 ? void 0 : _props$modelValue3.campaignId);
            });
            if (campaign) {
              var campaignDisplayName = campaign.isArchived ? "".concat(campaign.name || "Unknown Campaign", " (Archived)") : campaign.name || "Unknown Campaign";
              valueBuilder.addTextValue("Campaign", campaignDisplayName);
            }
            if ((_props$modelValue4 = props.modelValue) !== null && _props$modelValue4 !== void 0 && _props$modelValue4.subcampaignId && campaign !== null && campaign !== void 0 && campaign.subcampaigns) {
              var subcampaign = campaign.subcampaigns.find(sc => {
                var _props$modelValue5;
                return sc.id === ((_props$modelValue5 = props.modelValue) === null || _props$modelValue5 === void 0 ? void 0 : _props$modelValue5.subcampaignId);
              });
              if (subcampaign) {
                var subcampaignDisplayName = subcampaign.isArchived ? "".concat(subcampaign.name || "Unknown Subcampaign", " (Archived)") : subcampaign.name || "Unknown Subcampaign";
                valueBuilder.addTextValue("Subcampaign", subcampaignDisplayName);
              }
            }
            return valueBuilder.build();
          });
          return (_ctx, _cache) => {
            return openBlock(), createElementBlock("fieldset", null, [createVNode(unref(ValueDetailList), {
              modelValue: topValues.value
            }, null, 8, ["modelValue"]), createElementVNode("div", _hoisted_1, [createElementVNode("div", _hoisted_2, [createVNode(unref(ValueDetailList), {
              modelValue: leftSideValues.value
            }, null, 8, ["modelValue"])]), createElementVNode("div", _hoisted_3, [createVNode(unref(ValueDetailList), {
              modelValue: rightSideValues.value
            }, null, 8, ["modelValue"])])]), createVNode(unref(AttributeValuesContainer), {
              modelValue: attributeValues.value,
              attributes: attributes.value,
              numberOfColumns: 2
            }, null, 8, ["modelValue", "attributes"])]);
          };
        }
      });

      script$1.__file = "src/OverflowCampaignMapDetail/viewPanel.partial.obs";

      var NavigationUrlKey = function (NavigationUrlKey) {
        NavigationUrlKey["ParentPage"] = "ParentPage";
        return NavigationUrlKey;
      }({});

      var script = exports('default', defineComponent({
        __name: 'overflowCampaignMapDetail',
        setup(__props) {
          var config = useConfigurationValues();
          var invokeBlockAction = useInvokeBlockAction();
          onConfigurationValuesChanged(useReloadBlock());
          var blockError = ref("");
          var errorMessage = ref("");
          var overflowCampaignMapViewBag = ref(config.entity);
          var overflowCampaignMapEditBag = ref({
            bag: {}
          });
          var panelMode = ref(DetailPanelMode.View);
          var baseBlock = useEntityDetailBlock({
            blockConfig: config,
            entity: overflowCampaignMapEditBag
          });
          var panelName = computed(() => {
            var _overflowCampaignMapV;
            return ((_overflowCampaignMapV = overflowCampaignMapViewBag.value) === null || _overflowCampaignMapV === void 0 || (_overflowCampaignMapV = _overflowCampaignMapV.financialAccount) === null || _overflowCampaignMapV === void 0 ? void 0 : _overflowCampaignMapV.text) || "New Campaign Map";
          });
          var entityKey = computed(() => {
            var _overflowCampaignMapV2, _overflowCampaignMapV3;
            return (_overflowCampaignMapV2 = (_overflowCampaignMapV3 = overflowCampaignMapViewBag.value) === null || _overflowCampaignMapV3 === void 0 ? void 0 : _overflowCampaignMapV3.idKey) !== null && _overflowCampaignMapV2 !== void 0 ? _overflowCampaignMapV2 : "";
          });
          var blockLabels = computed(() => {
            var _overflowCampaignMapV4;
            var labels = [];
            if (panelMode.value !== DetailPanelMode.View) {
              return undefined;
            }
            if (((_overflowCampaignMapV4 = overflowCampaignMapViewBag.value) === null || _overflowCampaignMapV4 === void 0 ? void 0 : _overflowCampaignMapV4.isActive) === true) {
              labels.push({
                iconCssClass: "fa fa-lightbulb",
                title: "Active",
                type: "success"
              });
            } else {
              labels.push({
                iconCssClass: "far fa-lightbulb",
                title: "Inactive",
                type: "danger"
              });
            }
            return labels;
          });
          var isEditable = computed(() => {
            return config.isEditable === true;
          });
          var options = computed(() => {
            var _config$options;
            return (_config$options = config.options) !== null && _config$options !== void 0 ? _config$options : {};
          });
          function onCancelEdit() {
            return _onCancelEdit.apply(this, arguments);
          }
          function _onCancelEdit() {
            _onCancelEdit = _asyncToGenerator(function* () {
              var _overflowCampaignMapE;
              if (!((_overflowCampaignMapE = overflowCampaignMapEditBag.value.bag) !== null && _overflowCampaignMapE !== void 0 && _overflowCampaignMapE.idKey)) {
                var _config$navigationUrl;
                if ((_config$navigationUrl = config.navigationUrls) !== null && _config$navigationUrl !== void 0 && _config$navigationUrl[NavigationUrlKey.ParentPage]) {
                  return config.navigationUrls[NavigationUrlKey.ParentPage];
                }
                return false;
              }
              return true;
            });
            return _onCancelEdit.apply(this, arguments);
          }
          function onDelete() {
            return _onDelete.apply(this, arguments);
          }
          function _onDelete() {
            _onDelete = _asyncToGenerator(function* () {
              var _overflowCampaignMapV5;
              errorMessage.value = "";
              var result = yield invokeBlockAction("Delete", {
                key: (_overflowCampaignMapV5 = overflowCampaignMapViewBag.value) === null || _overflowCampaignMapV5 === void 0 ? void 0 : _overflowCampaignMapV5.idKey
              });
              if (result.isSuccess && result.data) {
                return result.data;
              } else {
                var _result$errorMessage;
                errorMessage.value = (_result$errorMessage = result.errorMessage) !== null && _result$errorMessage !== void 0 ? _result$errorMessage : "Unknown error while trying to delete overflow campaign map.";
                return false;
              }
            });
            return _onDelete.apply(this, arguments);
          }
          function onEdit() {
            return _onEdit.apply(this, arguments);
          }
          function _onEdit() {
            _onEdit = _asyncToGenerator(function* () {
              var _overflowCampaignMapV6;
              var result = yield invokeBlockAction("Edit", {
                key: (_overflowCampaignMapV6 = overflowCampaignMapViewBag.value) === null || _overflowCampaignMapV6 === void 0 ? void 0 : _overflowCampaignMapV6.idKey
              });
              if (result.isSuccess && result.data && result.data.bag) {
                var _result$data$validPro;
                overflowCampaignMapEditBag.value = {
                  bag: result.data.bag,
                  validProperties: (_result$data$validPro = result.data.validProperties) !== null && _result$data$validPro !== void 0 ? _result$data$validPro : Object.keys(result.data.bag)
                };
                return true;
              } else {
                return false;
              }
            });
            return _onEdit.apply(this, arguments);
          }
          function onSave() {
            return _onSave.apply(this, arguments);
          }
          function _onSave() {
            _onSave = _asyncToGenerator(function* () {
              var _result$errorMessage2;
              errorMessage.value = "";
              var result = yield invokeBlockAction("Save", {
                box: overflowCampaignMapEditBag.value
              });
              if (result.isSuccess && result.data) {
                if (result.statusCode === 200 && typeof result.data === "object") {
                  overflowCampaignMapViewBag.value = result.data.bag;
                  return true;
                } else if (result.statusCode === 201 && typeof result.data === "string") {
                  return result.data;
                }
              }
              errorMessage.value = (_result$errorMessage2 = result.errorMessage) !== null && _result$errorMessage2 !== void 0 ? _result$errorMessage2 : "Unknown error while trying to save overflow campaign map.";
              return false;
            });
            return _onSave.apply(this, arguments);
          }
          if (config.errorMessage) {
            blockError.value = config.errorMessage;
          } else if (!config.entity) {
            blockError.value = "The specified overflow campaign map could not be viewed.";
          } else if (!config.entity.idKey) {
            overflowCampaignMapEditBag.value = {
              bag: config.entity
            };
            panelMode.value = DetailPanelMode.Add;
          }
          return (_ctx, _cache) => {
            return openBlock(), createElementBlock(Fragment, null, [blockError.value ? (openBlock(), createBlock(unref(NotificationBox), {
              key: 0,
              alertType: "warning",
              innerHTML: blockError.value
            }, null, 8, ["innerHTML"])) : createCommentVNode("v-if", true), errorMessage.value ? (openBlock(), createBlock(unref(NotificationBox), {
              key: 1,
              alertType: "danger",
              innerHTML: errorMessage.value
            }, null, 8, ["innerHTML"])) : createCommentVNode("v-if", true), !blockError.value ? (openBlock(), createBlock(unref(DetailBlock), {
              key: 2,
              mode: panelMode.value,
              "onUpdate:mode": _cache[1] || (_cache[1] = $event => panelMode.value = $event),
              name: panelName.value,
              labels: blockLabels.value,
              entityKey: entityKey.value,
              isAuditHidden: false,
              isBadgesVisible: true,
              isDeleteVisible: isEditable.value,
              isEditVisible: isEditable.value,
              isFollowVisible: true,
              isSecurityHidden: false,
              onCancelEdit: onCancelEdit,
              onDelete: onDelete,
              onEdit: onEdit,
              onSave: onSave
            }, {
              view: withCtx(() => [createVNode(unref(script$1), {
                modelValue: overflowCampaignMapViewBag.value,
                options: options.value
              }, null, 8, ["modelValue", "options"])]),
              edit: withCtx(() => [createVNode(unref(script$2), {
                modelValue: overflowCampaignMapEditBag.value,
                "onUpdate:modelValue": _cache[0] || (_cache[0] = $event => overflowCampaignMapEditBag.value = $event),
                options: options.value,
                onPropertyChanged: unref(baseBlock).onPropertyChanged
              }, null, 8, ["modelValue", "options", "onPropertyChanged"])]),
              _: 1
            }, 8, ["mode", "name", "labels", "entityKey", "isDeleteVisible", "isEditVisible"])) : createCommentVNode("v-if", true)], 64);
          };
        }
      }));

      script.__file = "src/overflowCampaignMapDetail.obs";

    })
  };
}));
//# sourceMappingURL=overflowCampaignMapDetail.obs.js.map
