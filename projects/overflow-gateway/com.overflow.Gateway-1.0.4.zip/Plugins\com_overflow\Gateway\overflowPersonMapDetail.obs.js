System.register(['vue', '@Obsidian/Controls/notificationBox.obs', '@Obsidian/Templates/detailBlock', '@Obsidian/Enums/Controls/detailPanelMode', '@Obsidian/Controls/attributeValuesContainer.obs', '@Obsidian/Utility/block', '@Obsidian/Utility/component', '@Obsidian/Controls/personPicker.obs', '@Obsidian/Controls/textBox.obs', '@Obsidian/Controls/valueDetailList.obs', '@Obsidian/Core/Controls/valueDetailListItemBuilder'], (function (exports) {
  'use strict';
  var defineComponent, ref, watch, openBlock, createElementBlock, createElementVNode, createVNode, unref, isRef, computed, Fragment, createBlock, createCommentVNode, withCtx, NotificationBox, DetailBlock, DetailPanelMode, AttributeValuesContainer, setPropertiesBoxValue, watchPropertyChanges, useConfigurationValues, useInvokeBlockAction, onConfigurationValuesChanged, useReloadBlock, useEntityDetailBlock, propertyRef, updateRefValue, PersonPicker, TextBox, ValueDetailList, ValueDetailListItemBuilder;
  return {
    setters: [function (module) {
      defineComponent = module.defineComponent;
      ref = module.ref;
      watch = module.watch;
      openBlock = module.openBlock;
      createElementBlock = module.createElementBlock;
      createElementVNode = module.createElementVNode;
      createVNode = module.createVNode;
      unref = module.unref;
      isRef = module.isRef;
      computed = module.computed;
      Fragment = module.Fragment;
      createBlock = module.createBlock;
      createCommentVNode = module.createCommentVNode;
      withCtx = module.withCtx;
    }, function (module) {
      NotificationBox = module["default"];
    }, function (module) {
      DetailBlock = module["default"];
    }, function (module) {
      DetailPanelMode = module.DetailPanelMode;
    }, function (module) {
      AttributeValuesContainer = module["default"];
    }, function (module) {
      setPropertiesBoxValue = module.setPropertiesBoxValue;
      watchPropertyChanges = module.watchPropertyChanges;
      useConfigurationValues = module.useConfigurationValues;
      useInvokeBlockAction = module.useInvokeBlockAction;
      onConfigurationValuesChanged = module.onConfigurationValuesChanged;
      useReloadBlock = module.useReloadBlock;
      useEntityDetailBlock = module.useEntityDetailBlock;
    }, function (module) {
      propertyRef = module.propertyRef;
      updateRefValue = module.updateRefValue;
    }, function (module) {
      PersonPicker = module["default"];
    }, function (module) {
      TextBox = module["default"];
    }, function (module) {
      ValueDetailList = module["default"];
    }, function (module) {
      ValueDetailListItemBuilder = module.ValueDetailListItemBuilder;
    }],
    execute: (function () {

      function asyncGeneratorStep(n, t, e, r, o, a, c) {
        try {
          var i = n[a](c),
            u = i.value;
        } catch (n) {
          return void e(n);
        }
        i.done ? t(u) : Promise.resolve(u).then(r, o);
      }
      function _asyncToGenerator(n) {
        return function () {
          var t = this,
            e = arguments;
          return new Promise(function (r, o) {
            var a = n.apply(t, e);
            function _next(n) {
              asyncGeneratorStep(a, r, o, _next, _throw, "next", n);
            }
            function _throw(n) {
              asyncGeneratorStep(a, r, o, _next, _throw, "throw", n);
            }
            _next(void 0);
          });
        };
      }
      function _defineProperty(e, r, t) {
        return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
          value: t,
          enumerable: !0,
          configurable: !0,
          writable: !0
        }) : e[r] = t, e;
      }
      function ownKeys(e, r) {
        var t = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var o = Object.getOwnPropertySymbols(e);
          r && (o = o.filter(function (r) {
            return Object.getOwnPropertyDescriptor(e, r).enumerable;
          })), t.push.apply(t, o);
        }
        return t;
      }
      function _objectSpread2(e) {
        for (var r = 1; r < arguments.length; r++) {
          var t = null != arguments[r] ? arguments[r] : {};
          r % 2 ? ownKeys(Object(t), !0).forEach(function (r) {
            _defineProperty(e, r, t[r]);
          }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) {
            Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
          });
        }
        return e;
      }
      function _toPrimitive(t, r) {
        if ("object" != typeof t || !t) return t;
        var e = t[Symbol.toPrimitive];
        if (void 0 !== e) {
          var i = e.call(t, r || "default");
          if ("object" != typeof i) return i;
          throw new TypeError("@@toPrimitive must return a primitive value.");
        }
        return ("string" === r ? String : Number)(t);
      }
      function _toPropertyKey(t) {
        var i = _toPrimitive(t, "string");
        return "symbol" == typeof i ? i : i + "";
      }

      var _hoisted_1$1 = {
        class: "row"
      };
      var _hoisted_2$1 = {
        class: "col-md-6"
      };
      var _hoisted_3$1 = {
        class: "col-md-6"
      };
      var script$2 = defineComponent({
        __name: 'editPanel.partial',
        props: {
          modelValue: {
            type: Object,
            required: true
          },
          options: {
            type: Object,
            required: true
          }
        },
        emits: ["update:modelValue", "propertyChanged"],
        setup(__props, _ref) {
          var _props$modelValue$bag, _props$modelValue$bag2, _props$modelValue$bag3, _props$modelValue$bag4, _props$modelValue$bag5, _props$modelValue$bag6, _props$modelValue$bag7, _props$modelValue$bag8;
          var __emit = _ref.emit;
          var props = __props;
          var emit = __emit;
          var attributes = ref((_props$modelValue$bag = (_props$modelValue$bag2 = props.modelValue.bag) === null || _props$modelValue$bag2 === void 0 ? void 0 : _props$modelValue$bag2.attributes) !== null && _props$modelValue$bag !== void 0 ? _props$modelValue$bag : {});
          var attributeValues = ref((_props$modelValue$bag3 = (_props$modelValue$bag4 = props.modelValue.bag) === null || _props$modelValue$bag4 === void 0 ? void 0 : _props$modelValue$bag4.attributeValues) !== null && _props$modelValue$bag3 !== void 0 ? _props$modelValue$bag3 : {});
          var person = propertyRef((_props$modelValue$bag5 = (_props$modelValue$bag6 = props.modelValue.bag) === null || _props$modelValue$bag6 === void 0 ? void 0 : _props$modelValue$bag6.person) !== null && _props$modelValue$bag5 !== void 0 ? _props$modelValue$bag5 : {}, "person");
          var donorId = propertyRef((_props$modelValue$bag7 = (_props$modelValue$bag8 = props.modelValue.bag) === null || _props$modelValue$bag8 === void 0 ? void 0 : _props$modelValue$bag8.donorId) !== null && _props$modelValue$bag7 !== void 0 ? _props$modelValue$bag7 : "", "donorId");
          var propRefs = [person, donorId];
          watch(() => props.modelValue, () => {
            var _props$modelValue$bag9, _props$modelValue$bag0, _props$modelValue$bag1, _props$modelValue$bag10, _props$modelValue$bag11, _props$modelValue$bag12, _props$modelValue$bag13, _props$modelValue$bag14;
            updateRefValue(attributes, (_props$modelValue$bag9 = (_props$modelValue$bag0 = props.modelValue.bag) === null || _props$modelValue$bag0 === void 0 ? void 0 : _props$modelValue$bag0.attributes) !== null && _props$modelValue$bag9 !== void 0 ? _props$modelValue$bag9 : {});
            updateRefValue(attributeValues, (_props$modelValue$bag1 = (_props$modelValue$bag10 = props.modelValue.bag) === null || _props$modelValue$bag10 === void 0 ? void 0 : _props$modelValue$bag10.attributeValues) !== null && _props$modelValue$bag1 !== void 0 ? _props$modelValue$bag1 : {});
            updateRefValue(person, (_props$modelValue$bag11 = (_props$modelValue$bag12 = props.modelValue.bag) === null || _props$modelValue$bag12 === void 0 ? void 0 : _props$modelValue$bag12.person) !== null && _props$modelValue$bag11 !== void 0 ? _props$modelValue$bag11 : {});
            updateRefValue(donorId, (_props$modelValue$bag13 = (_props$modelValue$bag14 = props.modelValue.bag) === null || _props$modelValue$bag14 === void 0 ? void 0 : _props$modelValue$bag14.donorId) !== null && _props$modelValue$bag13 !== void 0 ? _props$modelValue$bag13 : "");
          });
          watch([attributeValues, ...propRefs], () => {
            var newValue = {
              bag: _objectSpread2({}, props.modelValue.bag)
            };
            setPropertiesBoxValue(newValue, "attributeValues", attributeValues.value);
            setPropertiesBoxValue(newValue, "person", person.value);
            setPropertiesBoxValue(newValue, "donorId", donorId.value);
            emit("update:modelValue", newValue);
          });
          watchPropertyChanges(propRefs, emit);
          return (_ctx, _cache) => {
            return openBlock(), createElementBlock("fieldset", null, [createElementVNode("div", _hoisted_1$1, [createElementVNode("div", _hoisted_2$1, [createVNode(unref(PersonPicker), {
              modelValue: unref(person),
              "onUpdate:modelValue": _cache[0] || (_cache[0] = $event => isRef(person) ? person.value = $event : null),
              label: "Person",
              rules: "required"
            }, null, 8, ["modelValue"])]), createElementVNode("div", _hoisted_3$1, [createVNode(unref(TextBox), {
              label: 'Donor ID',
              modelValue: unref(donorId),
              "onUpdate:modelValue": _cache[1] || (_cache[1] = $event => isRef(donorId) ? donorId.value = $event : null),
              rules: "required",
              placeholder: 'Enter the donor ID'
            }, null, 8, ["modelValue"])])]), createVNode(unref(AttributeValuesContainer), {
              modelValue: attributeValues.value,
              "onUpdate:modelValue": _cache[2] || (_cache[2] = $event => attributeValues.value = $event),
              attributes: attributes.value,
              isEditMode: "",
              numberOfColumns: 2
            }, null, 8, ["modelValue", "attributes"])]);
          };
        }
      });

      script$2.__file = "src/OverflowPersonMapDetail/editPanel.partial.obs";

      var _hoisted_1 = {
        class: "row"
      };
      var _hoisted_2 = {
        class: "col-md-6"
      };
      var _hoisted_3 = {
        class: "col-md-6"
      };
      var script$1 = defineComponent({
        __name: 'viewPanel.partial',
        props: {
          modelValue: {
            type: Object,
            required: false
          },
          options: {
            type: Object,
            required: true
          }
        },
        setup(__props) {
          var _props$modelValue$att, _props$modelValue, _props$modelValue$att2, _props$modelValue2;
          var props = __props;
          var attributes = ref((_props$modelValue$att = (_props$modelValue = props.modelValue) === null || _props$modelValue === void 0 ? void 0 : _props$modelValue.attributes) !== null && _props$modelValue$att !== void 0 ? _props$modelValue$att : {});
          var attributeValues = ref((_props$modelValue$att2 = (_props$modelValue2 = props.modelValue) === null || _props$modelValue2 === void 0 ? void 0 : _props$modelValue2.attributeValues) !== null && _props$modelValue$att2 !== void 0 ? _props$modelValue$att2 : {});
          var topValues = computed(() => {
            var valueBuilder = new ValueDetailListItemBuilder();
            if (!props.modelValue) {
              return valueBuilder.build();
            }
            return valueBuilder.build();
          });
          var leftSideValues = computed(() => {
            var _props$modelValue$per;
            var valueBuilder = new ValueDetailListItemBuilder();
            if (!props.modelValue) {
              return valueBuilder.build();
            }
            valueBuilder.addTextValue("Person", ((_props$modelValue$per = props.modelValue.person) === null || _props$modelValue$per === void 0 ? void 0 : _props$modelValue$per.text) || "Unknown Person");
            return valueBuilder.build();
          });
          var rightSideValues = computed(() => {
            var valueBuilder = new ValueDetailListItemBuilder();
            if (!props.modelValue) {
              return valueBuilder.build();
            }
            valueBuilder.addTextValue("Donor ID", props.modelValue.donorId || "Unknown Donor ID");
            return valueBuilder.build();
          });
          return (_ctx, _cache) => {
            return openBlock(), createElementBlock("fieldset", null, [createVNode(unref(ValueDetailList), {
              modelValue: topValues.value
            }, null, 8, ["modelValue"]), createElementVNode("div", _hoisted_1, [createElementVNode("div", _hoisted_2, [createVNode(unref(ValueDetailList), {
              modelValue: leftSideValues.value
            }, null, 8, ["modelValue"])]), createElementVNode("div", _hoisted_3, [createVNode(unref(ValueDetailList), {
              modelValue: rightSideValues.value
            }, null, 8, ["modelValue"])])]), createVNode(unref(AttributeValuesContainer), {
              modelValue: attributeValues.value,
              attributes: attributes.value,
              numberOfColumns: 2
            }, null, 8, ["modelValue", "attributes"])]);
          };
        }
      });

      script$1.__file = "src/OverflowPersonMapDetail/viewPanel.partial.obs";

      var NavigationUrlKey = function (NavigationUrlKey) {
        NavigationUrlKey["ParentPage"] = "ParentPage";
        return NavigationUrlKey;
      }({});

      var script = exports('default', defineComponent({
        __name: 'overflowPersonMapDetail',
        setup(__props) {
          var config = useConfigurationValues();
          var invokeBlockAction = useInvokeBlockAction();
          onConfigurationValuesChanged(useReloadBlock());
          var blockError = ref("");
          var errorMessage = ref("");
          var overflowPersonMapViewBag = ref(config.entity);
          var overflowPersonMapEditBag = ref({
            bag: {}
          });
          var panelMode = ref(DetailPanelMode.View);
          var baseBlock = useEntityDetailBlock({
            blockConfig: config,
            entity: overflowPersonMapEditBag
          });
          var panelName = computed(() => {
            return "Overflow Person Map";
          });
          var entityKey = computed(() => {
            var _overflowPersonMapVie, _overflowPersonMapVie2;
            return (_overflowPersonMapVie = (_overflowPersonMapVie2 = overflowPersonMapViewBag.value) === null || _overflowPersonMapVie2 === void 0 ? void 0 : _overflowPersonMapVie2.idKey) !== null && _overflowPersonMapVie !== void 0 ? _overflowPersonMapVie : "";
          });
          var blockLabels = computed(() => {
            var labels = [];
            if (panelMode.value !== DetailPanelMode.View) {
              return undefined;
            }
            return labels;
          });
          var isEditable = computed(() => {
            return config.isEditable === true;
          });
          var options = computed(() => {
            var _config$options;
            return (_config$options = config.options) !== null && _config$options !== void 0 ? _config$options : {};
          });
          function onCancelEdit() {
            return _onCancelEdit.apply(this, arguments);
          }
          function _onCancelEdit() {
            _onCancelEdit = _asyncToGenerator(function* () {
              var _overflowPersonMapEdi;
              if (!((_overflowPersonMapEdi = overflowPersonMapEditBag.value.bag) !== null && _overflowPersonMapEdi !== void 0 && _overflowPersonMapEdi.idKey)) {
                var _config$navigationUrl;
                if ((_config$navigationUrl = config.navigationUrls) !== null && _config$navigationUrl !== void 0 && _config$navigationUrl[NavigationUrlKey.ParentPage]) {
                  return config.navigationUrls[NavigationUrlKey.ParentPage];
                }
                return false;
              }
              return true;
            });
            return _onCancelEdit.apply(this, arguments);
          }
          function onDelete() {
            return _onDelete.apply(this, arguments);
          }
          function _onDelete() {
            _onDelete = _asyncToGenerator(function* () {
              var _overflowPersonMapVie3;
              errorMessage.value = "";
              var result = yield invokeBlockAction("Delete", {
                key: (_overflowPersonMapVie3 = overflowPersonMapViewBag.value) === null || _overflowPersonMapVie3 === void 0 ? void 0 : _overflowPersonMapVie3.idKey
              });
              if (result.isSuccess && result.data) {
                return result.data;
              } else {
                var _result$errorMessage;
                errorMessage.value = (_result$errorMessage = result.errorMessage) !== null && _result$errorMessage !== void 0 ? _result$errorMessage : "Unknown error while trying to delete overflow person map.";
                return false;
              }
            });
            return _onDelete.apply(this, arguments);
          }
          function onEdit() {
            return _onEdit.apply(this, arguments);
          }
          function _onEdit() {
            _onEdit = _asyncToGenerator(function* () {
              var _overflowPersonMapVie4;
              var result = yield invokeBlockAction("Edit", {
                key: (_overflowPersonMapVie4 = overflowPersonMapViewBag.value) === null || _overflowPersonMapVie4 === void 0 ? void 0 : _overflowPersonMapVie4.idKey
              });
              if (result.isSuccess && result.data && result.data.bag) {
                var _result$data$validPro;
                overflowPersonMapEditBag.value = {
                  bag: result.data.bag,
                  validProperties: (_result$data$validPro = result.data.validProperties) !== null && _result$data$validPro !== void 0 ? _result$data$validPro : Object.keys(result.data.bag)
                };
                return true;
              } else {
                return false;
              }
            });
            return _onEdit.apply(this, arguments);
          }
          function onSave() {
            return _onSave.apply(this, arguments);
          }
          function _onSave() {
            _onSave = _asyncToGenerator(function* () {
              var _result$errorMessage2;
              errorMessage.value = "";
              var result = yield invokeBlockAction("Save", {
                box: overflowPersonMapEditBag.value
              });
              if (result.isSuccess && result.data) {
                if (result.statusCode === 200 && typeof result.data === "object") {
                  overflowPersonMapViewBag.value = result.data.bag;
                  return true;
                } else if (result.statusCode === 201 && typeof result.data === "string") {
                  return result.data;
                }
              }
              errorMessage.value = (_result$errorMessage2 = result.errorMessage) !== null && _result$errorMessage2 !== void 0 ? _result$errorMessage2 : "Unknown error while trying to save overflow person map.";
              return false;
            });
            return _onSave.apply(this, arguments);
          }
          if (config.errorMessage) {
            blockError.value = config.errorMessage;
          } else if (!config.entity) {
            blockError.value = "The specified overflow person map could not be viewed.";
          } else if (!config.entity.idKey) {
            overflowPersonMapEditBag.value = {
              bag: config.entity
            };
            panelMode.value = DetailPanelMode.Add;
          }
          return (_ctx, _cache) => {
            return openBlock(), createElementBlock(Fragment, null, [blockError.value ? (openBlock(), createBlock(unref(NotificationBox), {
              key: 0,
              alertType: "warning",
              innerHTML: blockError.value
            }, null, 8, ["innerHTML"])) : createCommentVNode("v-if", true), errorMessage.value ? (openBlock(), createBlock(unref(NotificationBox), {
              key: 1,
              alertType: "danger",
              innerHTML: errorMessage.value
            }, null, 8, ["innerHTML"])) : createCommentVNode("v-if", true), !blockError.value ? (openBlock(), createBlock(unref(DetailBlock), {
              key: 2,
              mode: panelMode.value,
              "onUpdate:mode": _cache[1] || (_cache[1] = $event => panelMode.value = $event),
              name: panelName.value,
              labels: blockLabels.value,
              entityKey: entityKey.value,
              isAuditHidden: false,
              isBadgesVisible: true,
              isDeleteVisible: isEditable.value,
              isEditVisible: isEditable.value,
              isFollowVisible: true,
              isSecurityHidden: false,
              onCancelEdit: onCancelEdit,
              onDelete: onDelete,
              onEdit: onEdit,
              onSave: onSave
            }, {
              view: withCtx(() => [createVNode(unref(script$1), {
                modelValue: overflowPersonMapViewBag.value,
                options: options.value
              }, null, 8, ["modelValue", "options"])]),
              edit: withCtx(() => [createVNode(unref(script$2), {
                modelValue: overflowPersonMapEditBag.value,
                "onUpdate:modelValue": _cache[0] || (_cache[0] = $event => overflowPersonMapEditBag.value = $event),
                options: options.value,
                onPropertyChanged: unref(baseBlock).onPropertyChanged
              }, null, 8, ["modelValue", "options", "onPropertyChanged"])]),
              _: 1
            }, 8, ["mode", "name", "labels", "entityKey", "isDeleteVisible", "isEditVisible"])) : createCommentVNode("v-if", true)], 64);
          };
        }
      }));

      script.__file = "src/overflowPersonMapDetail.obs";

    })
  };
}));
//# sourceMappingURL=overflowPersonMapDetail.obs.js.map
